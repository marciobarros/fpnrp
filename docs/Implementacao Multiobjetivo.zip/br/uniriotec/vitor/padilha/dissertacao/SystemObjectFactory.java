package br.uniriotec.vitor.padilha.dissertacao;

import javax.xml.bind.annotation.XmlRegistry;


@XmlRegistry
public class SystemObjectFactory {

}
