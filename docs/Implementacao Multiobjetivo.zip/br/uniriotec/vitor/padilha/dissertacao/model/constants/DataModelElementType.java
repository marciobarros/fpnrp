package br.uniriotec.vitor.padilha.dissertacao.model.constants;

public enum DataModelElementType {
	 EIF,
	 ILF
}
