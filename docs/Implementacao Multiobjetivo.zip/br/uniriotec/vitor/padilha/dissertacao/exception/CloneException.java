package br.uniriotec.vitor.padilha.dissertacao.exception;

public class CloneException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6828558370581556577L;

}
