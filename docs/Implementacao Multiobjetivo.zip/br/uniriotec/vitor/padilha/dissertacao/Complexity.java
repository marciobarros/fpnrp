package br.uniriotec.vitor.padilha.dissertacao;

public enum Complexity {

	LOW,
	MEDIUM,
	HIGH
}
