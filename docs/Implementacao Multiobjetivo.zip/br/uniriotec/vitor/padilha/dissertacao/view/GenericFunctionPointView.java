package br.uniriotec.vitor.padilha.dissertacao.view;

public abstract class GenericFunctionPointView implements IFunctionPointView{

	
}
