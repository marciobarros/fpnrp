package br.uniriotec.ese.constantes;

public enum DistribuicaoDosDados {
	SOBOL,
	PSEUD
}
