package br.uniriotec.sain.entity;

public class Generic {

}
