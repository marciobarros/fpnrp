package br.uniriotec.sain.entity;

public enum TipoPagamento {
	PAGAMENTO_MENSAL,
	DECIMO_TERCEIRO,
	SEMANAL,
	POR_SERVICO
}
